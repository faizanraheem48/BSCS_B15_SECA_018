# My Card
## Flutter Application

## IOs and Android 

Mi Card is a personal business card. Imagine every time you wanted to give someone your contact details or your business card but you didn't have it on you. Well, now you can get them to download your business card as an app.

## Screenshot

![image](https://github.com/zeeshanayaz/my-card-Flutter-App/blob/master/images/mi-card-app-screenshot-android.png)